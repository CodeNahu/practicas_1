/** \brief Realiza la suma de dos numeros enteros.
 *
 * \param Pide el primer numero entero.
 * \param Pide el segundo numero entero.
 * \return Retorna un numero entero.
 *
 */
int suma(int a, int b);

/** \brief Realiza la resta de dos numeros en enteros.
 *
 * \param Pide el primer numero entero.
 * \param Pide el segundo numero entero.
 * \return Retorna un numero entero.
 *
 */
int resta(int a, int b);

/** \brief Realiza una multiplicacion entre dos enteros.
 *
 * \param Pide el primer numero entero.
 * \param Pide el segundo numero entero.
 * \return Retorna un numero entero.
 *
 */
int multiplicacion( int a, int b);

/** \brief Realiza la division de dos numeros enteros.
 *
 * \param Pide el primer numero entero.
 * \param Pide el segundo numero entero.
 * \return Retorna un numero flotante.
 *
 */
float division(int a, int b);

/** \brief Realiza el factorial de un numero.
 *
 * \param Pide un numero entero.
 * \return Retorna un numero long.
 *
 */
long factorial(int a);
