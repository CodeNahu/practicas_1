#include "funciones.h"


int suma(int a, int b)
{
    int resultado;

    resultado = a + b;

    return resultado;
}

int resta(int a, int b)
{

    int resultado;
    resultado= a - (b);

    return resultado;
}


int multiplicacion( int a, int b)
{

    int resultado;
    resultado= a * b;

    return resultado;
}

float division(int a, int b)
{

    float resultado;

    resultado=(float) a / b;


    return resultado;
}

long int factorial(int a)
{

    long factorial=1;
    int i;

    for(i=a; i>=1; i--)
    {

        factorial = factorial * i;
    }
    return factorial;
}






