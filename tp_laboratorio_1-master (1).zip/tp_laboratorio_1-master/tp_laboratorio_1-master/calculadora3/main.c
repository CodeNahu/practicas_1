#include <stdio.h>
#include <stdlib.h>
#include "funciones.h"
int main()
{

    int salir=0;
    int opciones;
    int operando1;
    int operando2;
    int Numero=0;
    int Numero2=0;
    int sumar;
    int restar;
    float dividir;
    int multiplicar;
    long factor1;
    long factor2;
    int vanderaOperaciones=0;



    do
    {

        fflush(stdin);
        printf ("Seleccione una opcion\n");
        if(Numero==1)
        {
            printf("1. Ingrese primer operando: A= %d\n",operando1);

        }
        else
        {
            printf("1. Ingrese primer operando\n");
        }
        if(Numero2==1)
        {
            printf("2. Ingrese segundo operando: B= %d\n",operando2);
        }
        else
        {
            printf("2. Ingrese segundo operando\n");
        }
        printf("3. Calcular operaciones\n");
        printf("4. Informar resultados\n");
        printf("5. salir\n");
        printf("La opcion es: ");
        scanf("%d",&opciones);

        switch(opciones)
        {
        case 1:
            printf("Ingrese primer operando: ");
            Numero=scanf("%d",&operando1);
            vanderaOperaciones=0;
            fflush(stdin);
            while(Numero!=1)
            {
                printf("incorrecto, ingrese primer operando: ");
                fflush(stdin);
                Numero=scanf("%d",&operando1);
            }

            break;

        case 2:
            if(Numero==1)
            {
                printf("Ingrese segundo operando: ");
                Numero2=scanf("%d",&operando2);
                vanderaOperaciones=0;
                fflush(stdin);
                while(Numero2!=1)
                {
                    printf("incorrecto, ingrese segundo operando: ");
                    fflush(stdin);
                    Numero2=scanf("%d",&operando2);
                }
            }
            else
            {
                printf("Primero ingrese operando 1\n");
            }

            break;

        case 3:
            if(Numero2==1 && Numero==1)
            {
                sumar=suma(operando1,operando2);
                restar=resta(operando1,operando2);
                dividir=division(operando1,operando2);
                multiplicar=multiplicacion(operando1,operando2);
                factor1=factorial(operando1);
                factor2=factorial(operando2);
                printf("Operaciones realizadas\n");
                vanderaOperaciones=1;
            }
            else
            {
                printf("Error, no se ingreso operandos\n");
            }

            break;

        case 4:
            if(Numero2==1 && Numero==1)
            {
                if(vanderaOperaciones==1)
                {
                    fflush(stdin);
                    printf("El resultado de A+B es: %d\n",sumar);
                    printf("El resultado de A-B es: %d\n",restar);
                    if(operando1==0 || operando2==0)
                    {
                        printf("No es posible dividir por cero\n");
                    }
                    else
                    {
                        printf("El reultado de A/b es: %.2f\n",dividir);
                    }
                    printf("El resultado de A*B es: %d\n",multiplicar);
                    if(operando1<0 || operando2<0)
                    {
                        if(operando1<0 && operando2>=0)
                        {
                            printf("No es posible calcular el factorial de A por que es negativo. El factorial de B es: %ld\n",factor2);
                        }
                        else if(operando2<0 && operando1>=0)
                        {
                            printf("No es posible calcular el factorial de B por que es negativo. El factorial de A es: %ld\n",factor1);
                        }
                        else
                        {
                            printf("No es posible calcular el factorial de A y B por que ambos son negativos.\n");
                        }
                    }
                    else
                    {
                        printf("El factorial de A es: %ld y El factorial de B es: %ld\n",factor1,factor2);
                    }

                }
                else if(vanderaOperaciones==0)
                {
                    printf("Primero aceda a la opcion 3 para realizar las operaciones\n");
                }
            }
            else
            {
                printf("Primero aceda a la opcion 3 para realizar las operaciones\n");
            }
            break;
        case 5:
            salir=1;
            break;
        default:
            printf("Opcion incorrecta\n");
            break;
        }
        system("pause");
        system("cls");

    }
    while(salir!=1);

    return 0;

}
